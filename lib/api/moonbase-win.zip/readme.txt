MewnBase

A planet exploration and survival game with base building.
Created by Cairn4 - http://cairn4.com
Twitter: https://twitter.com/cairn4

---

About

MewnBase is a game about wandering around a barren planet, finding resources and surviving. Scavenge around for items to keep you fed. Build up your base with new modules to replenish your suit power and oxygen.

Because MewnBase in active development there are definitely bugs, and features are subject to change. Many parts of the design I'm still working on figuring out as I go! 


Game Modes

Tutorial - Teaches you the very basics of how to play.
Normal Mission - Survive for X days, and take off in the Lander and you win!
Creative Mode - Free crafting, and infinite hunger, health and oxygen.


Controls

Left Mouse Button - interact / pick up item.
Right Mouse Button - place base module (press and hold to pickup base modules).

WASD - Move around!
Q - Drop item. Shift+Q drops a whole stack
F - Flashlight
M - Show/hide map
R - Rotates the airlock base module while it's being placed.
Enter - enter/exit vehicles
Spacebar - Buggie drift/powerslide and Dozer Drill
Esc - Pause game or close any open menu
F1 - open dev / cheat console. Type "help" to see commands.


---

I'm always excited to hear your feedback! Post comments, questions, problems on game's message board here:
https://cairn4.itch.io/MewnBase/community

You can also email me: steve@cairn4.com


---

Monetization Permission

Cairn4 allows for the contents of MewnBase to be published through video broadcasting services for any commercial or non-commercial purposes, YouTube, Twitch etc. Monetization of videos created containing assets from MewnBase is legally & explicitly allowed by Cairn4.